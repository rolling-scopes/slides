var svg = d3.select('body').append('svg')
    .attr('height', 800)
    .attr('width', 800);
    
d3.json('data/belarus.topojson', function(error, belarus) {
    if(error) return console.error(error);
    
    var states = topojson.feature(belarus, belarus.objects.states);
    
    var projection = d3.geo.mercator()
        .translate([400, 400])
        .rotate([-27.55, 0])
        .center([0, 53.916667])
        .scale(2200);
        
    var path = d3.geo.path()
        .projection(projection);
        
    //STATES
    svg.selectAll('.state')
        .data(states.features)
        .enter().append('path')
        .attr('class', function (d) { return 'state ' + d.id; })
        .attr('d', path);
        
    //BOUNDARIES
    var mesh = topojson.mesh(
        belarus, belarus.objects.states,
        function(a, b) { return a !== b; }
    );

    svg.append('path')
        .datum(mesh)
        .attr('d', path)
        .attr('class', 'state-boundary');
        
    var places = topojson.feature(belarus, belarus.objects.places);
    
    //POINTS
    svg.append('path')
      .datum(places)
      .attr('d', path)
      .attr('class', 'place-point');

    //LABELS
    svg.selectAll('.place-label')
        .data(places.features)
        .enter().append('text')
        .attr('class', function (d) {
            return 'place-label ' + d.properties.name;
         })
        .attr('transform', function(d) {
            return 'translate(' + projection(d.geometry.coordinates) + ')';
        })
        .attr('dy', function (d) {
          if(d.properties.name === 'Maladzyechna') {
            return '-0.35em'
          }
          return '.35em';
        })
        .attr('dx', 7)
        .text(function(d) { return d.properties.name; });
});