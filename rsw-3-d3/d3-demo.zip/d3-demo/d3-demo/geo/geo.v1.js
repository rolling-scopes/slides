var svg = d3.select('body').append('svg')
    .attr('height', 800)
    .attr('width', 800);
    
d3.json('data/belarus.topojson', function(error, belarus) {
    if(error) return console.error(error);
    
    svg.append('path')
        .datum(topojson.feature(belarus, belarus.objects.states))
        .attr('d', d3.geo.path().projection(d3.geo.mercator()));
});