var svg = d3.select('body').append('svg')
    .attr('height', 800)
    .attr('width', 800);
    
d3.json('data/belarus.topojson', function(error, belarus) {
    if(error) return console.error(error);
    
    var states = topojson.feature(belarus, belarus.objects.states);
    
    var projection = d3.geo.mercator()
        .translate([400, 400])
        .rotate([-27.55, 0])
        .center([0, 53.916667])
        .scale(2200);
        
    var path = d3.geo.path()
        .projection(projection);
    
    svg.selectAll('.state')
        .data(states.features)
        .enter().append('path')
        .attr('class', function (d) { return 'state ' + d.id; })
        .attr('d', path);
});