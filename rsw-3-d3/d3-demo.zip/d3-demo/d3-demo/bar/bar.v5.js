var body = d3.select('body');

function barChart(data) {
    var scale = d3.scale.linear()
        .domain([0, d3.max(data)])
        .range([0, document.body.clientWidth]);
        
    //JOIN
    var binding = body.selectAll('div')
        .data(data);
    
    //UPDATE    
    binding.style('background-color', 'blue');
    
    //ENTER
    binding.enter().append('div');
    
    //UPDATE + ENTER
    binding.transition()
        .style('width', function (d) { return scale(d) + 'px'})
        .text(function (d) { return d; });
    
    //EXIT
    binding.exit().style('background-color', 'red').remove();
}

barChart(data);
setInterval(function () {
    d3.shuffle(data);
    barChart(data);
}, 2500);
