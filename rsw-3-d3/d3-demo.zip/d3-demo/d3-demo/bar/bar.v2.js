function barChart(data) {
  data.forEach(function (d) {
    d3.select('body').append('div')
      .style('width', d * 100 + 'px')
      .text(d);
  });
}

barChart(data);