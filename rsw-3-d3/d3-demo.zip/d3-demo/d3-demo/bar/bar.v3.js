var body = d3.select('body');
body.append('div');
body.append('div');
body.append('div');

function barChart(data) {
    //JOIN
    var binding = body.selectAll('div')
        .data(data);
    
    //UPDATE    
    binding.style('background-color', 'blue');
    
    //ENTER
    binding.enter().append('div');
    
    //UPDATE + ENTER
    binding.style('width', function (d) { return d * 100 + 'px'})
        .text(function (d) { return d; });
    
    //EXIT
    binding.exit().style('background-color', 'red').remove();
}

barChart([1,2,3]);