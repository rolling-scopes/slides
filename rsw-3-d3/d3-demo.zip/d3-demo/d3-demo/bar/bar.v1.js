function barChart(data) {
    data.forEach(function (d) {
       var bar = document.createElement('div');
       document.body.appendChild(bar);
       bar.style.setProperty('width', d * 100 + 'px');
       bar.innerText = d;
    });
}

barChart(data);