var height = document.body.clientHeight,
	width = document.body.clientWidth,
	size = Math.min(height, width),
	r = size / 2;

var svg = d3.select('body').append('svg')
	.attr('height', size)
	.attr('width', size)
	.append('g')
	.attr('transform', 'translate(' + [r, r] + ')');
	
var pie = d3.layout.pie()
	.sort(null);
	
var arc = d3.svg.arc()
	.innerRadius(r / 2)
	.outerRadius(r);
	
function donutChart(data) {
	var binding = svg.selectAll('path')
		.data(pie(data));
		
	binding.enter().append('path');
	
	binding.attr('d', arc);
	
	binding.exit().remove();
}

donutChart(data);