var height = document.body.clientHeight,
	width = document.body.clientWidth,
	size = Math.min(height, width),
	r = size / 2;

var svg = d3.select('body').append('svg')
	.attr('height', size)
	.attr('width', size)
	.append('g')
	.attr('transform', 'translate(' + [r, r] + ')');
	
var pie = d3.layout.pie()
	.sort(null);
	
var arc = d3.svg.arc()
	.innerRadius(r / 2)
	.outerRadius(r);
	
var color = d3.scale.category10();
	
function donutChart(data) {
	var binding = svg.selectAll('g')
		.data(pie(data));
		
	var enter = binding.enter().append('g');
	
	enter.append('path')
		.attr('fill', function (d, i) { return color(i); })
		.attr('d', arc)
		.each(function(d) { this._current = d; }); // store the initial angles
	enter.append('text');
	
	binding.select('path')
		.transition()
		.attrTween('d', arcTween)
		.attr('fill', function(d, i) { return color(i); });
		
	binding.select('text')
		.text(function (d) { return d.value; })
		//translate to arc's center
		.attr('transform', function (d) {
			return 'translate(' + arc.centroid(d) + ')';
		})
		//center horizontally
		.attr('text-anchor', 'middle')
		//center vertically
		.attr('dy', '.35em');
	
	binding.exit().remove();
}

// Store the displayed angles in _current.
// Then, interpolate from _current to the new angles.
// During the transition, _current is updated in-place by d3.interpolate.
function arcTween(a) {
  var i = d3.interpolate(this._current, a);
  this._current = i(0);
  return function(t) {
    return arc(i(t));
  };
}

donutChart(data);
setInterval(function () {
	d3.shuffle(data);
	donutChart(data);
}, 2500);