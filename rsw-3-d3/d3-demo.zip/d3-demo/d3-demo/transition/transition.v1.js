var circle = d3.select('circle');

state1 = {
  r: 100,
  fill: 'red',
  cx: 200,
  cy: 200,
  opacity: 0.5
};

state2 = {
  r: 300,
  fill: 'blue',
  cx: 400,
  cy: 400,
  opacity: 1
};

function applyState(state) {
  circle.transition()
    .duration(2500)
    .ease('elastic')
    .attr('r', state.r)
    .attr('fill', state.fill)
    .attr('cx', state.cx)
    .attr('cy', state.cy)
    .style('opacity', state.opacity);
}

var i = 0;
applyState(state1);
setInterval(function () {
  var state = ++i % 2 === 0 ? state1 : state2;
  applyState(state);
}, 2500)