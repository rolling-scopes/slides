window.onload=function(){
	var d = document,
		myImgs = d.querySelectorAll('#wrapper .layer'),
		len = myImgs.length,
		W = window.innerWidth,
		H = window.innerHeight,
		hW = W/2, // The variable need in order not perform calculations in a loop
		hH = H/2,
		step = 12,	// The animation max step. Variable need to multilayered shape is not torn when driving.
					// Value is experimentally
		destination_x = current_x = hW, // start position
		destination_y = current_y = hH;

	(function() {
		d.body.setAttribute("style","width: " + W + "px; height: " + H + "px;"); // Remove the scroll bars
		for (var i = len; --i >= 0;) {
			myImgs[i].style.left = hW + 'px'; // set start position
			myImgs[i].style.top = hH + 'px';
			myImgs[i].style.marginLeft = '-' + (myImgs[i].offsetWidth)/2 + 'px';
			myImgs[i].style.marginTop = '-' + (myImgs[i].offsetHeight)/2 + 'px';
		}
	})();

	function mover() {
		if (destination_x != current_x && destination_y != current_y) { // do not do the calculations if the coordinates are the same
			for (var i = 0; i < len; i += 1) {
				var current_x = parseInt(myImgs[i].style.left, 10),
					current_y = parseInt(myImgs[i].style.top, 10);
				if (i !== len - 1) { // if this is not the top layer
					myImgs[i].style.left = myImgs[i+1].style.left; // using coordinates higher layer
					myImgs[i].style.top = myImgs[i+1].style.top;
				} else { // the top layer
					var dx = Math.abs(current_x - destination_x), // absolute value of the difference between the coordinates
						dy = Math.abs(current_y - destination_y),
						tg = dx/dy;	// Factor that regulates the movement of the shortest paths
									// in the presence of maximum step movement. Analogue velocity.
									// For a proper understanding helps a theorem of similarity triangles,
									// trigonometry, and a couple of bottles of beer
					if (dx <= step && dy <= step) { // iterate variants of moving the mouse to the ratio of the maximum step
						current_x = destination_x;
						current_y = destination_y;
					}
					if (dx > step && dy <= step) {
						current_x += (current_x < destination_x)?step:-step; // define the coordinate increases or decreases
						current_y += (current_y < destination_y)?(step/tg):-(step/tg);
					}
					if (dx <= step && dy > step) {
						current_x += (current_x < destination_x)?(step*tg):-(step*tg);
						current_y += (current_y < destination_y)?step:-step;
					}
					if (dx > step && dy > step) {
						if (dx > dy) {
							current_x += (current_x < destination_x)?step:-step;
							current_y += (current_y < destination_y)?(step/tg):-(step/tg);
						}
						if (dx < dy) {
							current_x += (current_x < destination_x)?(step*tg):-(step*tg);
							current_y += (current_y < destination_y)?step:-step;
						}
						if (dx == dy) {
							current_x += (current_x < destination_x)?step:-step;
							current_y += (current_y < destination_y)?step:-step;
						}
					}
					myImgs[i].style.left = current_x + 'px';
					myImgs[i].style.top = current_y + 'px';
				}
			}
			setTimeout(function() {	// repeated using a function call to complete the movement,
									// it means that all layers should be arranged strictly one above the other.
					mover();
			}, 15);
		}
	}

	mover();

	function mousePos(e) { // get the coordinates of the cursor after the move
		destination_x = e.pageX;
		destination_y = e.pageY;
	};

	d.addEventListener('mousemove', mousePos, false); // listen to move the cursor and process event

	setTimeout(function() { // remove the invisible block with animated clouds to improve performance
		var clouds = document.querySelector('#clouds');
		clouds.parentNode.removeChild(clouds);
	}, 15000);

}